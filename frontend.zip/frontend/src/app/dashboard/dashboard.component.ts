import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  products: Object[];
  totalPrice = 0;
  constructor(private api:ApiService) {
    this.products = [
      {
        name: "Product 1",
        id: "product1"
      },
      {
        name: "Product 2",
        id: "product2"
      },
      {
        name: "Product 3",
        id: "product3"
      },
      {
        name: "Product 4",
        id: "product4"
      },
      {
        name: "Product 5",
        id: "product5"
      },
    ];
   }

  ngOnInit() {
    
  }
  onSubmit(e)
  {
    const  productQty = {
      product1 : e.controls.product1.value,
      product2 : e.controls.product2.value,
      product3 : e.controls.product3.value,
      product4 : e.controls.product4.value,
      product5 : e.controls.product5.value
    }
    this.api.cart(productQty).subscribe((x:any)=>{
      console.log(x);
      if(x)
      {
        this.totalPrice = x.totalPrice;
      }
      else
      {
        this.totalPrice = 0;
      }
    },
    error => {
      window.alert('Something went wrong, please try again later');
      this.totalPrice = 0;
    }
    );
  }

}
