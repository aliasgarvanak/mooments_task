2) Back End - Laravel
- This is used to perfrom the back end tasks whose requests coming from the front end by the user and perform the logics and give the output.

Download the script : https://github.com/aliasgarvanak/mooments_backend.git

Open the script folder in to the terminal and run the following commands :
php artisan serve

- After running that commands, all the necessary packages will be installed and laravel project will open in to the browser with the following URL : http://127.0.0.1:8000/

- Database file, I have also added as mooments.sql in the root folder of backend. You can directly import it in to the database.So, you will get all the tables which is required in this project.