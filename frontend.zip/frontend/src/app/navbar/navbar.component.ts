import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
 
  isLoggedIn = false;
  username = '';
  constructor(private api:ApiService,private route:Router) { }

  ngOnInit() {
    /*this.api.isUserLogggedIn.subscribe(val=> {
      console.log(val);
      if(val)
      {
        this.isLoggedIn = val
        const user = JSON.parse(localStorage.getItem('user'));
        console.log(user);
        this.username = user.name;
      }
    });*/
    this.api.checkLogin;
    const token = localStorage.getItem('access_token');
    if(token)
    {
      this.isLoggedIn = true;
      const user = JSON.parse(localStorage.getItem('user'));
      this.username = user.name;
    }
    else{
      this.isLoggedIn = false;
      this.username = 'Guest';
    }
  }

  logout()
  {
    this.api.logoutUser();
    this.isLoggedIn = false;
    this.route.navigate(['/login']);
    //this.api.checkLogin;
  }
}
