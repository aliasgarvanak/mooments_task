import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loggedIn = false;
  constructor(private api:ApiService,private route:Router) { }

  ngOnInit() {
  }

  onSubmit(e)
  {
   const  user = {
      email : e.controls.email.value,
      password : e.controls.password.value
    }
    this.api.loginUser(user);
    this.api.isUserLogggedIn.subscribe(val=>{
      this.loggedIn = val;
      this.route.navigate(['/dashboard']);
    });
  }

}
