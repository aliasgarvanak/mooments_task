import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  registered:boolean = false;
  constructor(private api:ApiService,private route:Router) { }

  ngOnInit() {
  }

  onSubmit(e)
  {
   const  user = {
      name : e.controls.name.value,
      email : e.controls.email.value,
      password : e.controls.password.value
    }
    this.api.registerUser(user).subscribe((x:any)=>{
      if(x.access_token)
      {
        window.alert('Registration successfull');
        this.registered = true;
        this.route.navigate(['/login']);
      }
    },
    error => {
      window.alert('Validation failed during registration');
      this.registered = false;
    }
    );
  }

}
