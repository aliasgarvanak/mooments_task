import { Configuration } from './configuration';

describe('Configuration', () => {
  it('should create an instance', () => {
    expect(new Configuration()).toBeTruthy();
  });
});
