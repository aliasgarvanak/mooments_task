import { Injectable } from '@angular/core';
import {Configuration} from './configuration';
import {HttpClient} from '@angular/common/http';
import { BehaviorSubject, from } from 'rxjs';
import { JwtHelperService } from '@auth0/angular-jwt';



@Injectable({
  providedIn: 'root'
})
export class ApiService {
 
  config = new Configuration();
 
  checkStatus = new BehaviorSubject<boolean>(false);
  isUserLogggedIn = this.checkStatus.asObservable();
  
  constructor(private http:HttpClient) { }

  checkLogin()
  {
    const token = localStorage.getItem('access_token');
    if(token)
    {
      this.checkStatus.next(true);
    }
    else{
      this.checkStatus.next(false);
    }
    //this.checkStatus.next(status);
    
  }

  registerUser(user:any)
  {
    return this.http.post(this.config.apiUrl+'/register',user);
  }

  cart(productQty)
  {
    return this.http.post(this.config.apiUrl+'/cart',productQty);
  }

  loginUser(user:any)
  {
    return this.http.post(this.config.apiUrl+'/login',user)
    .subscribe((checkUser:any)=>{
      if(checkUser.access_token)
      {
        window.alert('You have been logged in successfully');
        localStorage.setItem('access_token',checkUser.access_token);
        localStorage.setItem('user',JSON.stringify(checkUser.user));
        this.checkLogin();
      }
    });
  }

  logoutUser()
  {
    return this.http.post(this.config.apiUrl+'/logout',{token:localStorage.getItem('access_token')})
    .subscribe(message=>{
      if(message)
      {
        window.alert('You have been logged out successfully');
        localStorage.removeItem('access_token');
        localStorage.removeItem('user');
        this.checkLogin();
      }
    });
  }
}
